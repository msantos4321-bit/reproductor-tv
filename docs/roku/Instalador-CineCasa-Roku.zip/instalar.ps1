﻿# Instalador de CineCasa para teles Roku (para distribuidores).
# Busca las teles Roku en tu WiFi, abre el modo desarrollador y sube la versión más reciente de CineCasa.
$ErrorActionPreference = 'Stop'
$Host.UI.RawUI.WindowTitle = 'Instalar CineCasa en Roku'
$ZipUrl = 'https://msantos4321-bit.github.io/reproductor-tv/roku/CineCasa-roku.zip'

function Titulo($t) { Write-Host ''; Write-Host "== $t ==" -ForegroundColor Cyan }

function Buscar-Rokus {
  $found = @{}
  try {
    $udp = New-Object System.Net.Sockets.UdpClient
    $udp.Client.ReceiveTimeout = 1200
    $msg = "M-SEARCH * HTTP/1.1`r`nHost: 239.255.255.250:1900`r`nMan: `"ssdp:discover`"`r`nST: roku:ecp`r`nMX: 2`r`n`r`n"
    $bytes = [Text.Encoding]::ASCII.GetBytes($msg)
    $ep = New-Object System.Net.IPEndPoint ([Net.IPAddress]::Parse('239.255.255.250')), 1900
    1..3 | ForEach-Object { [void]$udp.Send($bytes, $bytes.Length, $ep); Start-Sleep -Milliseconds 300 }
    $remote = New-Object System.Net.IPEndPoint ([Net.IPAddress]::Any), 0
    $until = (Get-Date).AddSeconds(4)
    while ((Get-Date) -lt $until) {
      try {
        $r = [Text.Encoding]::ASCII.GetString($udp.Receive([ref]$remote))
        if ($r -match '(?im)^LOCATION:\s*http://([0-9\.]+):8060') { $found[$Matches[1]] = $true }
      } catch { }
    }
    $udp.Close()
  } catch { }
  $list = @()
  foreach ($ip in $found.Keys) {
    $name = 'Roku'
    try {
      [xml]$x = (Invoke-WebRequest -Uri "http://${ip}:8060/query/device-info" -UseBasicParsing -TimeoutSec 4).Content
      $d = $x.'device-info'
      $name = @($d.'user-device-name', $d.'friendly-device-name', $d.'model-name') | Where-Object { $_ } | Select-Object -First 1
    } catch { }
    $list += [pscustomobject]@{ Ip = $ip; Nombre = $name }
  }
  return $list
}

function Tecla($ip, $k) { try { Invoke-WebRequest -Uri "http://${ip}:8060/keypress/$k" -Method Post -UseBasicParsing -TimeoutSec 4 | Out-Null } catch { } ; Start-Sleep -Milliseconds 450 }

Clear-Host
Write-Host 'CineCasa para Roku - instalador' -ForegroundColor White
Write-Host 'La computadora y la tele deben estar en el mismo WiFi.' -ForegroundColor Gray

Titulo 'Buscando teles Roku'
$rokus = Buscar-Rokus
if ($rokus.Count -eq 0) {
  Write-Host 'No encontré teles Roku automáticamente.' -ForegroundColor Yellow
  Write-Host 'En la tele: Configuración > Red > Acerca de. Ahí sale la "Dirección IP" (ej. 192.168.1.50).'
  $ip = Read-Host 'Escribe la dirección IP de la tele'
} else {
  for ($i = 0; $i -lt $rokus.Count; $i++) { Write-Host ("  {0}) {1}  ({2})" -f ($i + 1), $rokus[$i].Nombre, $rokus[$i].Ip) }
  $n = 1
  if ($rokus.Count -gt 1) { $n = [int](Read-Host 'Número de la tele donde vas a instalar') }
  $ip = $rokus[$n - 1].Ip
  Write-Host ("Tele elegida: {0} ({1})" -f $rokus[$n - 1].Nombre, $ip) -ForegroundColor Green
}

Titulo 'Modo desarrollador'
$devOk = $false
try { $t = Invoke-WebRequest -Uri "http://$ip/" -UseBasicParsing -TimeoutSec 4; $devOk = $true } catch { if ($_.Exception.Response) { $devOk = $true } }
if (-not $devOk) {
  Write-Host 'Esta tele todavía no tiene el modo desarrollador. Lo abro en la tele ahora...'
  Tecla $ip 'Home'; Start-Sleep 2
  foreach ($k in 'Home','Home','Home','Up','Up','Right','Left','Right','Left','Right') { Tecla $ip $k }
  Write-Host ''
  Write-Host 'En la tele:' -ForegroundColor Yellow
  Write-Host '  1. Elige "Enable installer and restart" (Activar instalador y reiniciar).'
  Write-Host '  2. Acepta el acuerdo ("I Agree").'
  Write-Host '  3. Escribe una contraseña. Usa siempre la misma, por ejemplo: cinecasa'
  Write-Host '  4. Espera a que la tele se reinicie.'
  Read-Host 'Cuando la tele termine de reiniciar, presiona Enter aquí'
}
$pw = Read-Host 'Contraseña del modo desarrollador de esa tele (la que pusiste, ej. cinecasa)'

Titulo 'Descargando la versión más reciente de CineCasa'
$zip = Join-Path $env:TEMP 'CineCasa-roku.zip'
Invoke-WebRequest -Uri $ZipUrl -OutFile $zip -UseBasicParsing
Write-Host 'Listo.'

Titulo 'Instalando en la tele'
$out = & curl.exe -s --digest -u "rokudev:$pw" -F 'mysubmit=Install' -F "archive=@$zip" "http://$ip/plugin_install" 2>&1 | Out-String
if ($out -match 'Install Success|Identical to previous|Received') {
  Write-Host 'CineCasa quedó instalada en la tele.' -ForegroundColor Green
  try { Invoke-WebRequest -Uri "http://${ip}:8060/launch/dev" -Method Post -UseBasicParsing -TimeoutSec 4 | Out-Null } catch { }
  Write-Host 'Ya se abrió en la tele. Para actualizarla en el futuro, vuelve a abrir este instalador.'
} elseif ($out -match '401|Unauthorized') {
  Write-Host 'La contraseña no es correcta. Vuelve a abrir el instalador y escríbela otra vez.' -ForegroundColor Red
} else {
  Write-Host 'No se pudo instalar. Revisa que la tele siga encendida y en el mismo WiFi.' -ForegroundColor Red
  Write-Host $out
}
Write-Host ''
Read-Host 'Presiona Enter para cerrar'
